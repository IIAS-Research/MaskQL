"""Archive only the latest completed validation run and its source provenance."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
RUN = BASE / 'validation'
OUT = ROOT / 'docs/publication/validation/2026-09-15-fixes'
OUT.mkdir(parents=True, exist_ok=True)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

tox = json.loads((RUN / 'logs/tox.json').read_text())
assert tox['exit_code'] == 0
unit = (RUN / 'source/.tox/int/log/2-commands[0].log').read_text()
match = re.search(r'Ran (\d+) tests in ([\d.]+)s\n\nOK\s*$', unit)
assert match, unit[-1000:]
names = re.findall(r'^(test_\w+) \(([^)]+)\)', unit, flags=re.M)
assert len(names) == int(match[1]) == 71
assert sum(module.startswith('test_catalog_service.') for _, module in names) == 15
steps = {}
for path in sorted((RUN / 'source/.tox/int/log').glob('[123]-*.log')):
    exit_code = int(re.search(r'^exit_code: (\d+)', path.read_text(), flags=re.M)[1])
    assert exit_code == 0
    steps[path.name] = exit_code
compose = (RUN / 'source/.tox/int/log/compose.log').read_text()
loading = [line for line in compose.splitlines() if '[EdsPseudoBridge] Loading EDS pipeline' in line]
ready = [line for line in compose.splitlines() if '[EdsPseudoBridge] EDS pipeline ready' in line]
server = [line for line in compose.splitlines() if '======== SERVER STARTED ========' in line]
assert len(loading) == len(ready) == len(server) == 1
assert compose.index(loading[0]) < compose.index(ready[0]) < compose.index(server[0])
source_manifest = json.loads((RUN / 'source-sha256.json').read_text())
source_changed = [name for name, expected in source_manifest.items() if digest((RUN / 'source' / name).read_bytes()) != expected]
assert not source_changed, source_changed
root_changed = [name for name, expected in source_manifest.items() if digest((ROOT / name).read_bytes()) != expected]
assert root_changed == ['examples/unstructured/README.md'], root_changed
source_info = {
    'base_version': '1.6.0',
    'base_commit': 'f7dd60ece3926378d99b90b7c02fcb6d6dde2d48',
    'status': 'local corrected worktree; not a published release',
    'source_patch_sha256': digest((RUN / 'source.patch').read_bytes()),
    'tracked_file_count': len(source_manifest),
    'changes_in_executed_copy_after_freeze': source_changed,
    'root_changes_after_freeze': root_changed,
    'root_change_explanation': 'Documentation only: clarify that graceful shutdown waits at most 10 seconds.'
}
summary = {
    'date': '2026-09-15', 'source': source_info,
    'python': {
        'total': int(match[1]), 'passed': int(match[1]), 'failures': 0, 'errors': 0, 'skipped': 0,
        'unit_catalog': 15, 'unit_catalog_using_mocks': 14, 'unit_catalog_pure_function': 1,
        'integration': 56, 'unittest_duration_seconds': float(match[2]),
        'command_exit_code': 0, 'command_duration_seconds': tox['duration_seconds'],
        'tests': [{'name': name, 'class': module, 'result': 'passed'} for name, module in names]
    },
    'tox_steps': steps,
    'java': {'maven_test_execution': 'disabled by existing build script (-DskipTests)'},
    'nlp_lifecycle': {'loading': loading, 'ready': ready, 'server_started': server, 'model_load_count': 1},
    'cleanup': json.loads((RUN / 'cleanup.json').read_text())
}
write_json('summary.json', summary)
write_json('environment.json', json.loads((RUN / 'environment.json').read_text()))
commands = {'corrected_validation': [json.loads(path.read_text()) for path in sorted((RUN / 'logs').glob('*.json'))]}
assert all(command['exit_code'] == 0 for command in commands['corrected_validation'])
write_json('commands.json', commands)
shutil.copy2(RUN / 'source.patch', OUT / 'source.patch')
shutil.copy2(RUN / 'source-sha256.json', OUT / 'source-sha256.json')
write_json('source-integrity.json', source_info)

members = {}
def add(path, name):
    assert path.is_file(), path
    members[name] = path.read_bytes()
for path in sorted((RUN / 'logs').glob('*')):
    if path.is_file(): add(path, 'validation/logs/' + path.name)
for path in sorted((RUN / 'source/.tox/int/log').glob('*.log')):
    add(path, 'validation/tox/' + path.name)
for name in ('run_command.py','capture_environment.py','cleanup.json'):
    add(RUN / name, 'validation/' + name)
for path in sorted((RUN / 'image').glob('*')):
    add(path, 'validation/image/' + path.name)
for name in ('summary.json','environment.json','commands.json','source.patch','source-sha256.json','source-integrity.json'):
    add(OUT / name, 'provenance/' + name)
add(Path(__file__), 'archive_evidence.py')
add(ROOT / 'docs/publication/validation-corrections-2026-09-15.md', 'REPORT.md')
manifest = ''.join(f'{digest(data)}  {name}\n' for name,data in sorted(members.items()))
with zipfile.ZipFile(OUT / 'evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for name,data in sorted(members.items()): archive.writestr(name,data)
    archive.writestr('MANIFEST.sha256', manifest)
with zipfile.ZipFile(OUT / 'evidence.zip') as archive:
    assert archive.testzip() is None
    for name,data in members.items(): assert digest(archive.read(name)) == digest(data)
files = ['summary.json','environment.json','commands.json','source.patch','source-sha256.json','source-integrity.json','evidence.zip']
(OUT / 'SHA256SUMS').write_text(''.join(f'{digest((OUT / name).read_bytes())}  {name}\n' for name in files))
print(json.dumps({'archive': str(OUT / 'evidence.zip'), 'files': len(members), 'archive_bytes': (OUT / 'evidence.zip').stat().st_size, 'patch_sha256': source_info['source_patch_sha256']},indent=2))
