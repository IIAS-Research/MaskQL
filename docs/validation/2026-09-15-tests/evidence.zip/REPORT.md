# Validation de MaskQL — 15 septembre 2026

## Résultat

La suite complète `uv run tox`, exécutée sur une installation propre, réussit :
**71 tests réussis, zéro échec, zéro erreur, zéro test ignoré**, en 91,122 s
pour la suite unittest. La commande complète prend 174,414 s et retourne 0.
Les étapes de préparation, de tests et de nettoyage retournent toutes 0.

Ces résultats concernent **MaskQL 1.6.0 avec les corrections locales décrites
ci-dessous**, fondées sur le commit
`f7dd60ece3926378d99b90b7c02fcb6d6dde2d48`. Ils ne désignent pas une nouvelle
release publiée. Le [patch exact évalué](validation/2026-09-15-fixes/source.patch)
et les empreintes des sources sont conservés avec les preuves.

## Implémentation évaluée

### Déchiffrement des dates

`MaskCrypto.invertPermuteInRange32` dérive la clé PBKDF2 **une seule fois par
valeur**, puis la réutilise pendant les étapes de la permutation, comme
dans le chemin 64 bits existant.
Les 200 000 itérations PBKDF2-HMAC-SHA256, la clé de 256 bits, les domaines
et la permutation sont inchangés.

Les tests SQL vérifient le chiffrement et le déchiffrement des dates,
notamment les bornes `0001-01-01` et `9999-12-31`, `1969-12-31`, le
29 février 2000 et NULL.

### Chargement et utilisation du modèle texte

Le plugin charge le modèle et effectue la première inférence pendant
l'initialisation du plugin, avant que Trino soit déclaré prêt. Un thread
dédié crée, utilise et ferme l'interpréteur Python ; un seul modèle est
conservé par nœud. Les appels concurrents sont sérialisés sur ce thread.
Une erreur d'initialisation est propagée au démarrage. Le chemin
`EDS_PIPELINE_DIR` est corrigé vers `/opt/models/eds-pseudo-public` et utilisé
par le chargeur ; l'ancien réglage `EDS_REPO` reste prioritaire lorsqu'il
est défini. L'arrêt gracieux attend le thread jusqu'à dix secondes.

Dans la pile corrigée, les journaux montrent un seul chargement et une
seule confirmation de disponibilité du modèle, sur `eds-pseudo-worker`,
avant `SERVER STARTED`. Aucun nouveau chargement n'apparaît pendant les
tests. Le test de graine SQL passe, ainsi que huit requêtes sur
quatre connexions concurrentes, avec deux graines alternées. Un autre
test vérifie le texte extrait du PDF synthétique fourni dans le dépôt.

**Conséquence d'exploitation :** une seule inférence texte à la fois par
nœud Trino. Cette limite est documentée dans
[`examples/unstructured/README.md`](../../examples/unstructured/README.md).
Son effet sur le débit n'a pas été mesuré.

### Configuration de validation

- `tox.ini` transmet maintenant `MASKQL_IMAGE_TAG`, déjà reconnu par Compose,
  pour permettre de tester une image locale ou une version déterminée.
- `uv.lock` indique désormais 1.6.0 pour le paquet local, conformément à
  `pyproject.toml` et à l'application. Les dépendances verrouillées sont
  inchangées.
- Aucun délai maximal de requête ou de test n'a été augmenté. La limite
  Trino reste de deux minutes. Aucun échauffement réservé aux tests n'a
  été ajouté : l'initialisation appartient au plugin lui-même.

## Environnement et installation propre

Un nouveau répertoire source a été préparé dans
`.tox/publication-fixes-20260915/validation/source/`, sans environnement
virtuel ni répertoire tox préexistant. Les fichiers suivis du dépôt corrigé
ont été copiés et leurs SHA-256 enregistrés. `uv sync --frozen` a créé le
nouvel environnement avec les 80 paquets verrouillés, en réutilisant le
cache de téléchargement. Le plugin Java a été recompilé par la procédure
tox. Les conteneurs et volumes PostgreSQL/Trino étaient neufs.

| Composant | Version/configuration observée |
| --- | --- |
| Hôte | macOS 15.7.9, build 24G830, x86_64 ; Intel Core i5-8279U, 16 GiB |
| Docker | Desktop 4.39.0 ; Engine 28.0.1 ; Compose 2.33.1-desktop.1 |
| VM Docker | Linux 6.10.14-linuxkit, 8 vCPU, environ 7,66 GiB RAM |
| Runner | CPython 3.10.12 ; uv 0.4.10 ; tox 4.28.4 |
| Compilation plugin | OpenJDK 24.0.2 ; Maven 3.9.11 |
| Trino | 476 ; Java Temurin 24.0.1+9 |
| Backend | CPython 3.11.16 ; FastAPI 0.111.0 ; MaskQL 1.6.0 |
| Traitement texte | CPython 3.11.9 ; PseudoCare 0.1.6 ; EDS-NLP 0.20.0 ; PyTorch 2.4.1+cpu ; JEP 4.2.2 |
| Base synthétique | PostgreSQL 16.15 |

L'image Trino de validation est construite localement au-dessus d'une image
figée par son digest
`sha256:c2a1fb280ea4c204a4e06eb1a932feb2de585317d7a9cbfa548ae691687aab64`.
Elle remplace le chargeur Python et son chemin de modèle. Les JAR corrigés
sont compilés puis montés par la procédure tox habituelle ; leurs empreintes
dans le conteneur sont enregistrées. Les modèles et dépendances de l'image
de base sont réutilisés, sans téléchargement Hugging Face ni reconstruction
complète des couches Python/modèle.

L'image résultante porte le tag local
`rudymerieux/maskql-trino:publication-fixes-20260915`, avec l'identifiant
`sha256:8810739f8f0a5e88fac24cf2aa0213b1fd971501f295849c434a583fea6db998`.
Le backend inchangé reçoit le même suffixe de tag ; son identifiant reste
`sha256:f9bfe155961514e5386f01d71ab3ffa768bdc2a79524f69580b80eaa345a6c4e`.
Ces tags sont locaux et n'ont pas été publiés.

## Commandes et résultats

Depuis le répertoire source neuf, avec le Dockerfile de validation dans
`../image/` :

```bash
export JAVA_HOME=/usr/local/opt/openjdk/libexec/openjdk.jdk/Contents/Home
export PATH="$JAVA_HOME/bin:$PATH"
export UV_PYTHON=/Users/rudy/.local/share/uv/python/cpython-3.10.12-macos-x86_64-none/bin/python3.10
export HF_TOKEN=""
export MASKQL_IMAGE_TAG=publication-fixes-20260915
export MASKQL_TEST_PROJECT=maskql-tox-fix-validation
export MASKQL_TEST_PORT=28443
export MASKQL_TEST_POSTGRES_PORT=25439
export KEEP_TEST_STACK=0

uv sync --frozen
docker build --pull=false \
  --tag rudymerieux/maskql-trino:publication-fixes-20260915 ../image
docker tag \
  rudymerieux/maskql@sha256:f9bfe155961514e5386f01d71ab3ffa768bdc2a79524f69580b80eaa345a6c4e \
  rudymerieux/maskql:publication-fixes-20260915
uv run tox
```

| Vérification | Résultat |
| --- | --- |
| Installation `uv sync --frozen` | Code 0, environnement neuf |
| Compilation Java et préparation tox | Code 0 |
| Suite Python | 71 réussites / 0 échec / 0 erreur / 0 ignoré |
| Répartition Python | 15 tests unitaires catalogue (14 avec mocks, un test de fonction pure) ; 56 sur la pile en fonctionnement |
| Nouveaux tests | Dates limites/NULL, extraction PDF, graines et concurrence texte |
| Nettoyage tox | Code 0 ; journaux collectés ; volumes et conteneurs supprimés |
| Intégrité | Code, tests, verrou et configuration exécutés identiques aux fichiers corrigés du dépôt |

La commande `uv run tox` s'est déroulée de **09:36:57 à 09:39:52 UTC** le
15 septembre 2026. Ses avertissements restent dans les journaux, notamment
la vérification TLS désactivée pour les clients de cette pile synthétique
et l'utilisation par uv de `.venv` plutôt que de l'environnement tox vide.
La compilation Maven utilise `-DskipTests` : elle ne lance pas de suite
Java.
Le décompte de zéro test ignoré concerne la suite Python.
Les temps indiqués sont ceux de cette exécution, sans comparaison de
performance contrôlée. Cette exécution ne comprend pas les tests frontend,
le replay structuré ou le parcours navigateur.

## Preuves et portée

Voir [`validation/2026-09-15-fixes/`](validation/2026-09-15-fixes/README.md)
pour les résultats structurés, commandes, environnement, patch et archive
avec manifeste SHA-256. Le code applicatif et les tests n'ont pas changé
après leur copie de validation. Seule une précision de documentation sur
les dix secondes d'attente à l'arrêt a ensuite été ajoutée au README texte.

Ces vérifications établissent le comportement fonctionnel des cas testés.
Elles ne mesurent ni la précision de détection des identifiants, ni le
risque résiduel de réidentification, ni la capacité sous charge. Elles ne
constituent pas non plus une validation sur des données réelles ou sur
d'autres configurations matérielles. Avant soumission, le tag de release
et l'archive logicielle devront correspondre à la version corrigée retenue.
