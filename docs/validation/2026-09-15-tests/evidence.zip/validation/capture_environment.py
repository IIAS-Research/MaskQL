import hashlib, importlib.metadata as metadata, json, os, platform, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
project="maskql-tox-fix-validation"
commands={
 "docker_version":["docker","version"],
 "compose_version":["docker","compose","version"],
 "docker_resources":["docker","info","--format",'{{json .}}'],
 "trino_info":["docker","exec",project+"-trino-1","curl","-fsS","http://localhost:8080/v1/info"],
 "trino_java":["docker","exec",project+"-trino-1","java","-version"],
 "nlp_packages":["docker","exec",project+"-trino-1","python","-c",'import sys,json,importlib.metadata as m; print(json.dumps({"python":sys.version,"packages":{d.metadata["Name"]:d.version for d in m.distributions()}},sort_keys=True))'],
 "backend_packages":["docker","exec",project+"-maskql-dev-1","python","-c",'import sys,json,importlib.metadata as m; print(json.dumps({"python":sys.version,"packages":{d.metadata["Name"]:d.version for d in m.distributions()}},sort_keys=True))'],
 "postgres":["docker","exec",project+"-postgres-1","postgres","--version"],
 "mounted_plugin_hashes":["docker","exec",project+"-trino-1","sh","-c","sha256sum /usr/lib/trino/plugin/maskql-plugin/*.jar /app/load_edspseudo.py"],
 "nlp_threads":["docker","exec",project+"-trino-1","jcmd","1","Thread.print"],
}
results={}
for key,command in commands.items():
 p=subprocess.run(command,capture_output=True,text=True)
 output=p.stdout+p.stderr
 if key=="docker_resources" and p.returncode==0:
  info=json.loads(p.stdout); output=json.dumps({k:info[k] for k in ("KernelVersion","OperatingSystem","OSType","Architecture","NCPU","MemTotal","ServerVersion")})
 if key=="nlp_threads":
  (HERE/"logs/trino-fixed-threads.log").write_text(output)
  output="Full thread dump saved to logs/trino-fixed-threads.log"
 results[key]={"command":command,"exit_code":p.returncode,"output":output}
image_details=[]
for image in json.loads((HERE/"image-inspect.json").read_text()):
 image_details.append({key:image.get(key) for key in ("Id","RepoTags","RepoDigests","Created","Architecture","Os")})
data={"recorded_at_utc":datetime.now(timezone.utc).isoformat(),"host_platform":platform.platform(),"runner_python":sys.version,"runner_packages":{d.metadata["Name"]:d.version for d in metadata.distributions()},"images":image_details,"commands":results}
(HERE/"environment.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps({key:result["exit_code"] for key,result in results.items()}))
if any(result["exit_code"] for result in results.values()): sys.exit(1)
