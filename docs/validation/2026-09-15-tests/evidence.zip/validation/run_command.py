import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
environment = os.environ.copy()
environment.pop('VIRTUAL_ENV', None)
environment.update({
    'JAVA_HOME': '/usr/local/opt/openjdk/libexec/openjdk.jdk/Contents/Home',
    'UV_PYTHON': '/Users/rudy/.local/share/uv/python/cpython-3.10.12-macos-x86_64-none/bin/python3.10',
    'MASKQL_TEST_PROJECT': 'maskql-tox-fix-validation',
    'MASKQL_TEST_PORT': '28443',
    'MASKQL_TEST_POSTGRES_PORT': '25439',
    'KEEP_TEST_STACK': '0',
    'MASKQL_IMAGE_TAG': 'publication-fixes-20260915',
    'HF_TOKEN': '',
})
environment['PATH'] = environment['JAVA_HOME'] + '/bin:' + environment['PATH']
record = {
    'command': command,
    'shell_command': shlex.join(command),
    'cwd': str(HERE / 'source'),
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'environment_overrides': {key: environment[key] for key in (
        'JAVA_HOME', 'UV_PYTHON', 'MASKQL_TEST_PROJECT', 'MASKQL_TEST_PORT',
        'MASKQL_TEST_POSTGRES_PORT', 'KEEP_TEST_STACK', 'HF_TOKEN', 'MASKQL_IMAGE_TAG',
    )},
}
started = time.monotonic()
with (HERE / 'logs' / (label + '.log')).open('w') as output:
    output.write('$ ' + record['shell_command'] + '\n')
    output.flush()
    process = subprocess.run(command, cwd=HERE / 'source', env=environment,
                             stdout=output, stderr=subprocess.STDOUT)
record['exit_code'] = process.returncode
record['duration_seconds'] = round(time.monotonic() - started, 3)
record['finished_at_utc'] = datetime.now(timezone.utc).isoformat()
(HERE / 'logs' / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print((HERE / 'logs' / (label + '.log')).read_text()[-10000:])
sys.exit(process.returncode)
