"""Archive the successful example executions and their reproducible inputs."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=ROOT/'docs/publication/validation/2026-09-15-examples'
OUT.mkdir(parents=True,exist_ok=True)

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
def write(name,data): (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

structured=read(HERE/'results/structured/result.json')
text=read(HERE/'results/unstructured/report.json')
assert structured['passed'] and len(structured['checks'])==6 and all(structured['checks'].values())
assert all(structured['cleanup'].values())
assert text['summary']=={'queries_passed':5,'queries_failed':0,'checks_passed':9,'checks_failed':0,'success':True}
assert all(text['checks'].values())
commands=[read(path) for path in sorted((HERE/'logs').glob('*.json'))]
assert all(command['exit_code']==0 for command in commands)
source_hashes=read(HERE/'source-sha256.json')
for name,digest in source_hashes.items(): assert sha((HERE/'source'/name).read_bytes())==digest,name
changed_root=[name for name,digest in source_hashes.items() if sha((ROOT/name).read_bytes())!=digest]
assert changed_root==['Makefile'],changed_root
provenance={**read(HERE/'base.json'),'source_patch_sha256':sha((HERE/'source.patch').read_bytes()),'frozen_source_files':len(source_hashes),'source_integrity_verified':True,'root_differences':changed_root,'root_difference_explanation':'Uncommitted publication-docx target excluded from the example execution snapshot.'}
summary={'date':'2026-09-15','source':provenance,'structured':{'source_count':structured['source_row_count'],'visible_patient_ids':[r['patient_id'] for r in structured['rows']],'checks':structured['checks'],'cleanup':structured['cleanup'],'passed':structured['passed']},'text_pdf':text['summary'],'cleanup':read(HERE/'cleanup.json')}
write('summary.json',summary)
write('commands.json',commands)
for source,target in (
 ('environment.json','environment.json'),('source.patch','source.patch'),('source-sha256.json','source-sha256.json'),
 ('results/structured/result.json','structured-result.json'),('results/unstructured/report.json','text-report.json')):
    shutil.copy2(HERE/source,OUT/target)

members={}
def add(path,name): members[name]=path.read_bytes()
for path in sorted((HERE/'logs').glob('*')):
    if path.is_file(): add(path,'logs/'+path.name)
add(HERE/'source/.tox/int/log/compose.log','logs/compose.log')
for path in sorted((HERE/'results').rglob('*')):
    if path.is_file(): add(path,'results/'+str(path.relative_to(HERE/'results')))
for relative in (
 'examples/structured/README.md','examples/structured/run.py','examples/structured/rules.json','examples/structured/query.sql','examples/structured/expected.json',
 'examples/unstructured/README.md','examples/unstructured/run_examples.py','examples/unstructured/generate_pdf.py','examples/unstructured/clinical-note.txt','examples/unstructured/clinical-note.pdf','examples/unstructured/expected.json',
 'tests/fixtures/healthcare.sql','tests/postgresql-init.sql','docs/QUICKSTART.md','docs/VALIDATION.md'):
    add(HERE/'source'/relative,'source/'+relative)
for name in ('summary.json','commands.json','environment.json','source.patch','source-sha256.json','structured-result.json','text-report.json'):
    add(OUT/name,'provenance/'+name)
for name in ('run_command.py','capture_environment.py','archive_evidence.py','cleanup.json','base.json'):
    add(HERE/name,'recording/'+name)
# Include the exact local image recipe used with this committed runtime.
for name in ('Dockerfile','load_edspseudo.py'):
    add(ROOT/'.tox/publication-fixes-20260915/validation/image'/name,'image/'+name)
assert members['image/load_edspseudo.py']==(HERE/'source/trino/python/load_edspseudo.py').read_bytes()
add(ROOT/'docs/publication/validation-exemples-2026-09-15.md','REPORT.md')
manifest=''.join(f'{sha(data)}  {name}\n' for name,data in sorted(members.items()))
with zipfile.ZipFile(OUT/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(members.items()): z.writestr(name,data)
    z.writestr('MANIFEST.sha256',manifest)
with zipfile.ZipFile(OUT/'evidence.zip') as z:
    assert z.testzip() is None
    for name,data in members.items(): assert sha(z.read(name))==sha(data),name
files=['summary.json','commands.json','environment.json','source.patch','source-sha256.json','structured-result.json','text-report.json','evidence.zip']
(OUT/'SHA256SUMS').write_text(''.join(f'{sha((OUT/name).read_bytes())}  {name}\n' for name in files))
print(json.dumps({'members':len(members),'archive_bytes':(OUT/'evidence.zip').stat().st_size,'patch_sha256':provenance['source_patch_sha256']},indent=2))
