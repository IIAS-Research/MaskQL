import hashlib, importlib.metadata as metadata, json, platform, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone
HERE=Path(__file__).resolve().parent
project='maskql-tox-publication-examples'
commands={
 'macos':['sw_vers'],
 'docker':['docker','version','--format','{{json .}}'],
 'compose':['docker','compose','version'],
 'java_build':['java','-version'],
 'maven':['mvn','--version'],
 'uv':['uv','--version'],
 'trino_info':['docker','exec',project+'-trino-1','curl','-fsS','http://localhost:8080/v1/info'],
 'trino_java':['docker','exec',project+'-trino-1','java','-version'],
 'text_packages':['docker','exec',project+'-trino-1','python','-c','import sys,json,importlib.metadata as m; print(json.dumps({"python":sys.version,"packages":{n:m.version(n) for n in ("pseudocare","edsnlp","torch","jep")}}))'],
 'backend':['docker','exec',project+'-maskql-dev-1','python','--version'],
 'postgres':['docker','exec',project+'-postgres-1','postgres','--version'],
 'runtime_hashes':['docker','exec',project+'-trino-1','sh','-c','sha256sum /usr/lib/trino/plugin/maskql-plugin/*.jar /app/load_edspseudo.py'],
 'images':['docker','image','inspect','rudymerieux/maskql-trino:publication-fixes-20260915','rudymerieux/maskql:publication-fixes-20260915','--format','{{.Id}} {{json .RepoTags}}'],
}
results={}
for name,command in commands.items():
    p=subprocess.run(command,text=True,capture_output=True)
    results[name]={'command':command,'exit_code':p.returncode,'output':p.stdout+p.stderr}
    assert p.returncode==0,(name,p.stderr)
data={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'runner_python':sys.version,'runner_platform':platform.platform(),'runner_packages':{n:metadata.version(n) for n in ('trino','requests','tox')},'commands':results}
(HERE/'environment.json').write_text(json.dumps(data,indent=2)+'\n')
print('Environment and loaded artifact hashes recorded; all probes successful.')
