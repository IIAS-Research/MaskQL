# Étape 2 — Exemple reproductible sur les données actuelles

## Résultat

Le 15 septembre 2026, les exemples ont été exécutés sur une pile isolée avec
des volumes neufs : **6 contrôles structurés réussis** et **9 contrôles
texte/PDF réussis**, avec des codes de sortie 0.

L'exemple structuré utilise le jeu actuel de **200 patients synthétiques**
de `tests/fixtures/healthcare.sql`, le filtre `patient_id <= 3` et la
transformation `encrypt(last_name)`. Les données, règles, requête et scripts
existaient déjà ; les résultats attendus sont désormais fournis dans des
fichiers `expected.json` et enregistrés avec chaque exécution.

Le runtime est MaskQL 1.6.0 avec les correctifs du commit
`b58bdb7818592334eed93f38553ece8fd372cdc4`. Les adaptations des exemples
exécutées à cette étape sont identifiées par un patch et des empreintes
SHA-256 dans le [dossier de preuves](validation/2026-09-15-examples/README.md).
La suite de 71 tests de l'étape 1 n'a pas été relancée : cette étape vérifie
les deux exemples et ne modifie pas le code applicatif.

## Exemple structuré

### Entrées et configuration

| Élément | Fichier ou valeur |
| --- | --- |
| Données fictives | [`tests/fixtures/healthcare.sql`](../../tests/fixtures/healthcare.sql), 200 patients |
| Table | `administrative.patients` |
| Règle de table | `patient_id <= 3`, accès autorisé |
| Règle de colonne | `encrypt(last_name)`, accès autorisé |
| Règles exécutables | [`examples/structured/rules.json`](../../examples/structured/rules.json) |
| Attendus | [`examples/structured/expected.json`](../../examples/structured/expected.json) |
| Script | [`examples/structured/run.py`](../../examples/structured/run.py) |

Requête exécutée avant et après application des règles :

```sql
SELECT patient_id, last_name
FROM administrative.patients
ORDER BY patient_id;
```

Elle ne contient pas de `WHERE` : le filtrage provient de la règle MaskQL.

### Résultat attendu et obtenu

| Vérification | Attendu | Obtenu |
| --- | --- | --- |
| Entrée | 200 patients, IDs 1 à 200 | Conforme |
| Lignes conservées | IDs 1, 2 et 3 uniquement | Conforme |
| Lignes exclues | IDs 4 à 200 | Aucune de ces lignes retournée |
| Noms retournés | Trois valeurs non vides et chiffrées | Conforme |
| Aperçu avant transformation | Cinq lignes en clair | Conforme |
| Aperçu après transformation | Trois lignes identiques au résultat SQL masqué | Conforme |
| Déchiffrement avec la clé de test | Noms originaux des trois patients | Conforme |

Le déchiffrement retourne exactement :

| patient_id | last_name |
| --- | --- |
| 1 | Fictional-Martin |
| 2 | Fictional-Lefèvre |
| 3 | Fictional-O'Connor |

Les valeurs chiffrées réellement obtenues figurent dans
[`structured-result.json`](validation/2026-09-15-examples/structured-result.json).
Elles dépendent de la clé et du contexte du serveur ; les attendus ne figent
donc pas arbitrairement une chaîne chiffrée. Le contrôle de déchiffrement
confirme la correspondance avec les noms d'origine.

Le runner a terminé en **13,904 s**, avec ses **6 contrôles à vrai**.
L'utilisateur, le catalogue et leurs règles temporaires ont été supprimés.
Les 200 entrées, l'attendu, la requête, les règles, l'aperçu et les résultats
sont conservés dans l'archive. Le parcours graphique du navigateur n'a pas
été exécuté à cette étape ; l'aperçu a été vérifié par son API.

## Texte clinique fictif et PDF

Les fichiers existants
[`clinical-note.txt`](../../examples/unstructured/clinical-note.txt) et
[`clinical-note.pdf`](../../examples/unstructured/clinical-note.pdf) ont été
réutilisés sans modification. La note est en anglais et tous ses éléments
d'identité sont fictifs. Le PDF contient du texte sélectionnable.

Avec la graine `fictional-patient-142`, le runner exécute :

```sql
SELECT text_pseudo(?, ?);
SELECT from_utf8(pdf_to_text(from_base64(?)));
SELECT text_pseudo(from_utf8(pdf_to_text(from_base64(?))), ?);
```

Les entrées et la graine sont liées comme paramètres SQL. Les deux requêtes
de pseudonymisation sont répétées, soit **5 requêtes au total**.
Les [attendus](../../examples/unstructured/expected.json) vérifient :

- le contenu extrait du PDF, identique aux mots de la note dans le même ordre,
  en ignorant uniquement les différences d'espacement ;
- pour chacune des deux sorties pseudonymisées, un texte non vide, transformé,
  ne contenant plus l'IPP fictif `8000000142`, et identique lors d'un nouvel
  appel avec la même entrée et la même graine.

**Les 5 requêtes et les 9 contrôles réussissent**, en 14,474 s pour le runner.
Dans les deux sorties observées, l'IPP devient `00886535`. Ce remplacement
illustre cette exécution ; il ne constitue pas une valeur attendue universelle.
Les textes complets et leurs empreintes figurent dans l'archive, et le bilan
est consultable dans [`text-report.json`](validation/2026-09-15-examples/text-report.json).

Ces contrôles illustrent le fonctionnement et la composition des fonctions.
Le modèle EDS vise les textes cliniques français : cet exemple anglais ne
mesure pas sa précision, ni le retrait exhaustif de tous les identifiants.
Il ne vérifie pas l'OCR de PDF scannés. Les remplacements peuvent changer
avec les versions du modèle et de ses dépendances.

## Reproduction

Le [quickstart](../QUICKSTART.md) et la
[procédure de validation](../VALIDATION.md) donnent les commandes habituelles
et les certificats à utiliser. Une pile peut être démarrée directement pour
ces exemples, sans réexécuter toute la suite de tests.

Pour cette exécution, les commandes ci-dessous ont été lancées dans une
copie neuve du dépôt avec les adaptations des exemples appliquées :

```bash
export JAVA_HOME=/usr/local/opt/openjdk/libexec/openjdk.jdk/Contents/Home
export PATH="$JAVA_HOME/bin:$PATH"
export UV_PYTHON=/Users/rudy/.local/share/uv/python/cpython-3.10.12-macos-x86_64-none/bin/python3.10
export HF_TOKEN=""
export MASKQL_IMAGE_TAG=publication-fixes-20260915
export MASKQL_TEST_PROJECT=maskql-tox-publication-examples
export MASKQL_TEST_PORT=38443
export MASKQL_TEST_POSTGRES_PORT=35439
export KEEP_TEST_STACK=0
export MASKQL_HOST=localhost MASKQL_PORT=38443 MASKQL_SCHEME=https
export MASKQL_ADMIN_USER=admin MASKQL_ADMIN_PASSWORD=admin
export MASKQL_USER=demo MASKQL_PASSWORD=demo
export MASKQL_ENCRYPT_PASSWORD='change-me-16+chars'
export API_VERIFY_SSL=.tox/int/tmp/certs/server.crt.pem
export TRINO_VERIFY_SSL="$API_VERIFY_SSL"

uv sync --frozen
uv run --frozen python scripts/test_stack.py start
uv run --frozen python examples/structured/run.py --output ../results/structured
uv run --frozen python examples/unstructured/run_examples.py \
  --seed fictional-patient-142 --output ../results/unstructured
uv run --frozen python scripts/test_stack.py stop
```

Les deux runners ont été exécutés en parallèle sur cette pile. Ils utilisent
des comptes distincts et des ressources temporaires propres au replay
structuré. Les durées sont des observations de cette exécution, pas des
mesures de performance contrôlées.

Le tag d'image utilisé est local. L'archive fournit la recette pour le
reconstruire à partir du digest de base et du chargeur Python corrigé ; le
plugin Java est recompilé par le script de pile. Les versions observées
sont macOS 15.7.9 x86_64, Docker Desktop 4.39.0 / Engine 28.0.1 / Compose
2.33.1, CPython 3.10.12 pour les runners, Trino 476 / Java 24.0.1 et
PostgreSQL 16.15. Le traitement texte utilise CPython 3.11.9, PseudoCare
0.1.6, EDS-NLP 0.20.0, PyTorch 2.4.1+cpu et JEP 4.2.2.

## Preuves et nettoyage

Le [dossier de preuves](validation/2026-09-15-examples/README.md) regroupe
les commandes datées, l'environnement, le patch des exemples, les sources
et leurs empreintes, les résultats attendus et obtenus et les journaux de
cette exécution réussie. La vérification TLS était activée avec le
certificat local. Aucun jeton Hugging Face n'a été utilisé.

Les conteneurs, volumes et réseaux de la pile d'exemples ont été supprimés
après collecte des journaux. Le résultat de l'étape 1 reste distinct : ses
71 tests ne sont pas additionnés aux contrôles des exemples.
